# 🛰️ AgriDrone v2.0 — ESP32 Firmware Instructions

This directory contains the complete C++ Arduino sketches for the two onboard drone payload microcontrollers:

```
esp32_code/
├── esp32_cam/
│   └── esp32_cam.ino           # AI-Thinker OV2640 Aerial Video & Snapshot Firmware
└── esp32_sensor_node/
    └── esp32_sensor_node.ino   # Microclimate IoT Node (DHT22/DHT11 Telemetry)
```

---

## 🔒 Security Notice Before Uploading / Flashing
Before flashing, open each `.ino` sketch and enter your Wi-Fi credentials:
```cpp
const char* ssid     = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";
```
*(All credentials in this repository have been sanitized to placeholders for public safety.)*

---

## 1. Node A: ESP32-CAM (Optical Payload)
- **Board Selection**: In Arduino IDE, select `AI Thinker ESP32-CAM`.
- **Flash Settings**:
  - CPU Frequency: `240MHz (WiFi/BT)`
  - Flash Frequency: `80MHz`
  - Flash Mode: `QIO`
  - Partition Scheme: `Huge APP (3MB No OTA/1MB SPIFFS)`
- **Programming Note**:
  - Connect **IO0 to GND** during programming via FTDI USB-UART adapter.
  - Remove IO0-GND jumper and press Reset button to boot the camera into run mode.
- **Network Ports**:
  - Port `80`: Snapshot frame endpoint (`/capture`).
  - Port `81`: MJPEG live stream endpoint (`/stream`).

---

## 2. Node B: ESP32 Environmental Sensor Node
- **Board Selection**: `ESP32 Dev Module` or `NodeMCU-32S`.
- **Required Libraries**:
  - `DHT sensor library` by Adafruit
  - `Adafruit Unified Sensor`
- **Telemetry Protocol**:
  - Samples temperature (°C) and humidity (%) every second.
  - Sends HTTP POST payload: `{"temperature": 28.5, "humidity": 55.0}` to `http://<PC_IP>:5000/sensor`.
