/**
 * ============================================================================
 * AgriDrone v2.0 — ESP32-CAM Aerial Video & Snapshot Firmware
 * ============================================================================
 * Hardware Target: AI-Thinker ESP32-CAM (OV2640 2MP Camera Module)
 * 
 * Capabilities:
 *  - Port 80: High-speed HTTP JPEG capture endpoint (/capture) for ultra-stable
 *             canvas polling and frame acquisition by the Ground Station.
 *  - Port 81: Multipart MJPEG live video stream (/stream).
 *  - Auto-exposure, white-balance, and gain tuning optimized for outdoor foliar inspection.
 *
 * NOTE FOR GITHUB USERS:
 *  Wi-Fi credentials have been removed for privacy and security.
 *  Enter your local hotspot SSID and password below before flashing.
 * ============================================================================
 */

#include "esp_camera.h"
#include <WiFi.h>
#include "esp_timer.h"
#include "img_converters.h"
#include "Arduino.h"
#include "soc/soc.h"
#include "soc/rtc_cntl_reg.h"

// ============================================================================
// 1. WI-FI CREDENTIALS (REPLACE WITH YOUR NETWORK DETAILS)
// ============================================================================
const char* ssid     = "YOUR_WIFI_SSID";         // e.g. "AgriDrone-Hotspot"
const char* password = "YOUR_WIFI_PASSWORD";     // e.g. "DronePassword123"

// ============================================================================
// 2. AI-THINKER ESP32-CAM PIN DEFINITIONS
// ============================================================================
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27

#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

#define FLASH_LED_PIN      4

// HTTP Server Handles
WiFiServer server80(80);
WiFiServer server81(81);

void startCameraServer();

void setup() {
  // Disable brownout detector for stable Wi-Fi transmission bursts
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0);

  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println("\n\n========================================");
  Serial.println("  AgriDrone v2.0 - ESP32-CAM Booting...");
  Serial.println("========================================");

  pinMode(FLASH_LED_PIN, OUTPUT);
  digitalWrite(FLASH_LED_PIN, LOW); // Keep flash LED off initially

  // Configure Camera Parameters
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer   = LEDC_TIMER_0;
  config.pin_d0       = Y2_GPIO_NUM;
  config.pin_d1       = Y3_GPIO_NUM;
  config.pin_d2       = Y4_GPIO_NUM;
  config.pin_d3       = Y5_GPIO_NUM;
  config.pin_d4       = Y6_GPIO_NUM;
  config.pin_d5       = Y7_GPIO_NUM;
  config.pin_d6       = Y8_GPIO_NUM;
  config.pin_d7       = Y9_GPIO_NUM;
  config.pin_xclk     = XCLK_GPIO_NUM;
  config.pin_pclk     = PCLK_GPIO_NUM;
  config.pin_vsync    = VSYNC_GPIO_NUM;
  config.pin_href     = HREF_GPIO_NUM;
  config.pin_sccb_sda = SIOD_GPIO_NUM;
  config.pin_sccb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn     = PWDN_GPIO_NUM;
  config.pin_reset    = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  // Optimize buffer allocation based on PSRAM availability
  if (psramFound()) {
    Serial.println("✓ PSRAM detected (4MB) - Enabling High-Resolution SVGA Mode");
    config.frame_size = FRAMESIZE_VGA; // 640x480 optimal for real-time aerial processing
    config.jpeg_quality = 10;          // 0-63, lower means higher quality
    config.fb_count = 2;
  } else {
    Serial.println("! No PSRAM detected - Falling back to QVGA (320x240)");
    config.frame_size = FRAMESIZE_QVGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
  }

  // Camera Initialization
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("❌ Camera init failed with error 0x%x\n", err);
    return;
  }

  // Sensor adjustments for outdoor crop sunlight
  sensor_t * s = esp_camera_sensor_get();
  if (s != NULL) {
    s->set_brightness(s, 1);     // -2 to 2
    s->set_contrast(s, 1);       // -2 to 2
    s->set_saturation(s, 1);     // -2 to 2 (vibrant green canopy distinction)
    s->set_whitebal(s, 1);       // 0 = disable, 1 = enable
    s->set_awb_gain(s, 1);       // 0 = disable, 1 = enable
    s->set_wb_mode(s, 0);        // 0 to 4 - 0: Auto, 1: Sunny, 2: Cloudy
  }

  // Connect to Wi-Fi
  Serial.printf("Connecting to Wi-Fi SSID: %s ", ssid);
  WiFi.begin(ssid, password);
  int retryCount = 0;
  while (WiFi.status() != WL_CONNECTED && retryCount < 30) {
    delay(500);
    Serial.print(".");
    retryCount++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✓ Wi-Fi Connected Successfully!");
    Serial.printf("📷 Camera Web Server IP: http://%s\n", WiFi.localIP().toString().c_str());
    Serial.printf("📸 Snapshot Endpoint:   http://%s/capture\n", WiFi.localIP().toString().c_str());
    Serial.printf("🎥 MJPEG Stream:        http://%s:81/stream\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n❌ Wi-Fi Connection Failed. Please check SSID and Password.");
  }

  server80.begin();
  server81.begin();
}

void loop() {
  // Handle Port 80 Snapshot Requests (/capture)
  WiFiClient client80 = server80.available();
  if (client80) {
    String req = client80.readStringUntil('\r');
    client80.flush();

    if (req.indexOf("/capture") != -1) {
      camera_fb_t * fb = esp_camera_fb_get();
      if (!fb) {
        client80.println("HTTP/1.1 500 Camera Capture Failed\r\n\r\n");
      } else {
        client80.println("HTTP/1.1 200 OK");
        client80.println("Content-Type: image/jpeg");
        client80.println("Content-Disposition: inline; filename=capture.jpg");
        client80.println("Access-Control-Allow-Origin: *");
        client80.printf("Content-Length: %u\r\n\r\n", fb->len);
        client80.write(fb->buf, fb->len);
        esp_camera_fb_return(fb);
      }
    } else {
      // Default HTML status page
      client80.println("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n");
      client80.println("<h2>AgriDrone ESP32-CAM Node Online</h2>");
      client80.println("<p><a href='/capture'>Click to Capture Frame</a></p>");
    }
    client80.stop();
  }

  // Handle Port 81 MJPEG Stream Requests (/stream)
  WiFiClient client81 = server81.available();
  if (client81) {
    String req = client81.readStringUntil('\r');
    client81.flush();

    if (req.indexOf("/stream") != -1) {
      client81.println("HTTP/1.1 200 OK");
      client81.println("Content-Type: multipart/x-mixed-replace; boundary=123456789000000000000987654321");
      client81.println("Access-Control-Allow-Origin: *");
      client81.println();

      while (client81.connected()) {
        camera_fb_t * fb = esp_camera_fb_get();
        if (!fb) break;

        client81.println("--123456789000000000000987654321");
        client81.println("Content-Type: image/jpeg");
        client81.printf("Content-Length: %u\r\n\r\n", fb->len);
        client81.write(fb->buf, fb->len);
        client81.println();
        esp_camera_fb_return(fb);
        delay(40); // ~25 FPS transmission
      }
    }
    client81.stop();
  }
}
