/**
 * ============================================================================
 * AgriDrone v2.0 — ESP32 Microclimate Sensor Node (DHT22 / DHT11)
 * ============================================================================
 * Hardware Target: ESP32 Development Board (NodeMCU-32S / ESP32-WROOM-32)
 * Sensor:          DHT22 (AM2302) or DHT11 Digital Temperature & Humidity Sensor
 * 
 * Pinout:
 *  - Sensor VCC  -> ESP32 3V3 Pin
 *  - Sensor DATA -> ESP32 GPIO 4 (with 4.7kΩ - 10kΩ pull-up resistor to 3V3)
 *  - Sensor GND  -> ESP32 GND
 *
 * Operation:
 *  - Connects to UAV Ground Station Wi-Fi network.
 *  - Samples temperature (°C) and relative humidity (%).
 *  - Transmits JSON telemetry payload via HTTP POST to the Flask receiver (:5000/sensor).
 *  - Incorporates reconnection watchdog and LED heartbeat status.
 *
 * NOTE FOR GITHUB USERS:
 *  Wi-Fi credentials and PC IP have been sanitized for privacy.
 *  Update with your local network settings before flashing.
 * ============================================================================
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <DHT.h>

// ============================================================================
// 1. WI-FI & TELEMETRY CONFIGURATION (REPLACE WITH YOUR NETWORK DETAILS)
// ============================================================================
const char* ssid           = "YOUR_WIFI_SSID";             // e.g. "AgriDrone-Hotspot"
const char* password       = "YOUR_WIFI_PASSWORD";         // e.g. "DronePassword123"
const char* serverEndpoint = "http://YOUR_PC_IP:5000/sensor"; // e.g. "http://192.168.137.1:5000/sensor"

// ============================================================================
// 2. SENSOR & HARDWARE PIN DEFINITIONS
// ============================================================================
#define DHTPIN        4       // ESP32 GPIO connected to DHT data pin
#define DHTTYPE       DHT22   // Change to DHT11 if utilizing blue DHT11 module
#define STATUS_LED    2       // Built-in onboard blue LED (GPIO 2)

DHT dht(DHTPIN, DHTTYPE);

// Telemetry interval (milliseconds)
const unsigned long TELEMETRY_INTERVAL_MS = 1000; // 1.0 second transmission rate
unsigned long lastTransmissionTime = 0;

void setup() {
  Serial.begin(115200);
  pinMode(STATUS_LED, OUTPUT);
  digitalWrite(STATUS_LED, LOW);

  Serial.println("\n\n========================================");
  Serial.println("  AgriDrone v2.0 - Sensor Node Booting");
  Serial.println("========================================");

  // Initialize DHT Sensor
  dht.begin();
  Serial.println("✓ DHT Sensor Initialized on GPIO 4");

  // Connect to Wi-Fi
  Serial.printf("Connecting to Wi-Fi: %s ", ssid);
  WiFi.begin(ssid, password);

  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 30) {
    delay(500);
    Serial.print(".");
    digitalWrite(STATUS_LED, !digitalRead(STATUS_LED)); // Flash LED during connection
    retry++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✓ Connected to Ground Station Network!");
    Serial.printf("📡 Node IP Address: %s\n", WiFi.localIP().toString().c_str());
    Serial.printf("🎯 Target Receiver: %s\n", serverEndpoint);
    digitalWrite(STATUS_LED, HIGH); // Solid LED indicates active connection
  } else {
    Serial.println("\n❌ Wi-Fi Connection Timeout. Running in offline sensor diagnostic mode.");
  }
}

void loop() {
  unsigned long now = millis();
  if (now - lastTransmissionTime >= TELEMETRY_INTERVAL_MS) {
    lastTransmissionTime = now;

    // Read Environmental Telemetry
    float humidity = dht.readHumidity();
    float temperature = dht.readTemperature();

    // Check for sensor read errors
    if (isnan(humidity) || isnan(temperature)) {
      Serial.println("⚠️ Warning: Failed to read from DHT sensor! Check physical wiring and pull-up resistor.");
      return;
    }

    Serial.printf("🌡️ Telemetry Reading: Temp = %.1f °C | Humidity = %.1f %%\n", temperature, humidity);

    // If connected to Wi-Fi, post telemetry payload
    if (WiFi.status() == WL_CONNECTED) {
      HTTPClient http;
      http.begin(serverEndpoint);
      http.addHeader("Content-Type", "application/json");

      // Construct JSON Payload
      String payload = "{\"temperature\":" + String(temperature, 1) + 
                       ",\"humidity\":" + String(humidity, 1) + "}";

      int httpResponseCode = http.POST(payload);

      if (httpResponseCode > 0) {
        Serial.printf("  ✓ Transmitted to Ground Station [HTTP %d]\n", httpResponseCode);
        // Quick LED blink on successful transmission
        digitalWrite(STATUS_LED, LOW);
        delay(30);
        digitalWrite(STATUS_LED, HIGH);
      } else {
        Serial.printf("  ❌ HTTP POST failed. Error: %s\n", http.errorToString(httpResponseCode).c_str());
      }
      http.end();
    } else {
      Serial.println("  ! Wi-Fi disconnected. Attempting auto-reconnect...");
      WiFi.reconnect();
    }
  }
}
